-- PortYou Studio: V-Slice runtime (generated). Runs the V-Slice events inside Psych Engine.
--[[DATA]]

local E = {}
local PI = math.pi

-- ---------------------------------------------------------------- flixel easing (same maths as FlxEase)
local function bounceOut(t)
	if t < 1 / 2.75 then return 7.5625 * t * t
	elseif t < 2 / 2.75 then t = t - 1.5 / 2.75; return 7.5625 * t * t + 0.75
	elseif t < 2.5 / 2.75 then t = t - 2.25 / 2.75; return 7.5625 * t * t + 0.9375
	else t = t - 2.625 / 2.75; return 7.5625 * t * t + 0.984375 end
end
local IN = {
	linear = function(t) return t end,
	quad = function(t) return t * t end,
	cube = function(t) return t * t * t end,
	quart = function(t) return t * t * t * t end,
	quint = function(t) return t * t * t * t * t end,
	sine = function(t) return 1 - math.cos(t * PI / 2) end,
	expo = function(t) if t == 0 then return 0 end return 2 ^ (10 * (t - 1)) end,
	circ = function(t) return -(math.sqrt(1 - t * t) - 1) end,
	back = function(t) return t * t * (2.70158 * t - 1.70158) end,
	elastic = function(t)
		if t == 0 or t == 1 then return t end
		t = t - 1
		return -(2 ^ (10 * t) * math.sin((t - 0.4 / (2 * PI) * math.asin(1)) * (2 * PI) / 0.4))
	end,
	bounce = function(t) return 1 - bounceOut(1 - t) end,
}
local function getEase(name, dir)
	local n = string.lower(name or 'linear')
	dir = dir or 'Out'
	if n == 'smoothstep' then return function(t) return t * t * (3 - 2 * t) end end
	if n == 'smootherstep' then return function(t) return t * t * t * (t * (t * 6 - 15) + 10) end end
	local f = IN[n]
	if f == nil then return IN.linear end
	if n == 'linear' then return f end
	if dir == 'In' then return f end
	if dir == 'InOut' then
		return function(t) if t < 0.5 then return f(t * 2) / 2 end return 1 - f((1 - t) * 2) / 2 end
	end
	return function(t) return 1 - f(1 - t) end
end

-- ---------------------------------------------------------------- tiny tween engine
local tweens = {}
local function addTween(key, getter, setter, to, dur, ease)
	for i = #tweens, 1, -1 do
		if tweens[i].key == key then table.remove(tweens, i) end
	end
	if dur <= 0 then setter(to); return end
	local from = tonumber(getter())
	if from == nil then setter(to); return end
	tweens[#tweens + 1] = {key = key, set = setter, from = from, to = to, dur = dur, t = 0, ease = ease}
end
function onUpdate(elapsed)
	if DRUNK_TICK ~= nil then pcall(DRUNK_TICK, elapsed) end
	elapsed = tonumber(elapsed) or 0
	for i = #tweens, 1, -1 do
		local tw = tweens[i]
		tw.t = tw.t + elapsed
		local p = tw.t / tw.dur
		if p >= 1 then
			tw.set(tw.to)
			table.remove(tweens, i)
		else
			tw.set(tw.from + (tw.to - tw.from) * tw.ease(p))
		end
	end
end

-- ---------------------------------------------------------------- helpers
local function P(s)
	local t = {}
	for kv in string.gmatch(s or '', '[^;]+') do
		local k, v = string.match(kv, '^([^=]+)=(.*)$')
		if k then t[k] = v end
	end
	return t
end
local function num(v, d)
	local n = tonumber(v)
	if n == nil then return d end
	return n
end
local function steps(n) return n * stepCrochet / 1000 end
local NAMED = {black='000000', blue='0000FF', brown='8B4513', cyan='00FFFF', gray='808080', grey='808080', green='008000',
	lime='00FF00', magenta='FF00FF', orange='FFA500', pink='FFC0CB', purple='800080', red='FF0000', white='FFFFFF', yellow='FFFF00'}
local function colorOf(i)
	if type(i) == 'string' then
		local h = string.match(i, '^#?(%x%x%x%x%x%x)$') or string.match(i, '^0[xX]%x%x(%x%x%x%x%x%x)$') or string.match(i, '^#?%x%x(%x%x%x%x%x%x)$')
		if h then return h end
		if NAMED[string.lower(i)] then return NAMED[string.lower(i)] end
	end
	local n = tonumber(i)
	if n == nil then return 'FFFFFF' end            -- unknown colour: white, never black
	return PALETTE[math.floor(n) + 1] or 'FFFFFF'
end
local function truthy(v) return v == '1' or v == 'true' or v == true end
local function clampZoom(z) if z < 0.05 then return 0.05 end return z end
local function clamp01(v) if v < 0 then return 0 end if v > 1 then return 1 end return v end
local function camName(p) if truthy(p.applyToHud) then return 'camHUD' end return 'camGame' end

-- ---------------------------------------------------------------- events
E.VS_FocusCamera = function(p)
	local ch = math.floor(num(p.char, 0))
	local x, y = num(p.x, 0), num(p.y, 0)
	local slot = nil
	if ch == 0 then slot = 'boyfriend' elseif ch == 1 then slot = 'dad' elseif ch == 2 then slot = 'gf' end
	if slot ~= nil and SLOT[slot] ~= nil then
		x = x + getMidpointX(slot) + SLOT[slot].cx
		y = y + getMidpointY(slot) + SLOT[slot].cy
	end
	setProperty('isCameraOnForcedPos', true)
	local dur = steps(num(p.duration, 4))
	if p.ease == 'CLASSIC' or p.ease == 'INSTANT' then dur = 0 end
	local ease = getEase(p.ease, p.easeDir)
	addTween('fx', function() return getProperty('camFollow.x') end, function(v) setProperty('camFollow.x', v) end, x, dur, ease)
	addTween('fy', function() return getProperty('camFollow.y') end, function(v) setProperty('camFollow.y', v) end, y, dur, ease)
end

E.VS_ZoomCamera = function(p)
	local z = num(p.zoom, 1)
	if p.mode == 'stage' then z = z * STAGE_ZOOM end
	z = clampZoom(z)
	local dur = steps(num(p.duration, 4))
	if p.ease == 'INSTANT' then dur = 0 end
	local ease = getEase(p.ease, p.easeDir)
	addTween('zoom', function() return getProperty('camGame.zoom') end,
		function(v) setProperty('defaultCamZoom', v); setProperty('camGame.zoom', v) end, z, dur, ease)
end

E.VS_CameraFlash = function(p)
	cameraFlash(camName(p), colorOf(p.color), steps(num(p.duration, 4)), true)
end

E.VS_CameraFade = function(p)
	if truthy(p.shouldFadeIn) then
		cameraFlash(camName(p), colorOf(p.color), steps(num(p.duration, 4)), true)
	else
		cameraFade(camName(p), colorOf(p.color), steps(num(p.duration, 4)), true)
	end
end

E.VS_CameraRotate = function(p)
	local dur = steps(num(p.duration, 4))
	if p.ease == 'INSTANT' then dur = 0 end
	local ease = getEase(p.ease, p.easeDir)
	addTween('rg', function() return getProperty('camGame.angle') end, function(v) setProperty('camGame.angle', v) end, num(p.angleCamGame, 0), dur, ease)
	addTween('rh', function() return getProperty('camHUD.angle') end, function(v) setProperty('camHUD.angle', v) end, num(p.angleCamHUD, 0), dur, ease)
end

E.VS_CamToggleAlpha = function(p)
	local g, h = clamp01(num(p.v1, 1)), clamp01(num(p.v2, 1))
	local dur = steps(num(p.v3, 4))
	if p.v4 == 'INSTANT' then dur = 0 end
	local ease = getEase(p.v4, p.v5)
	addTween('ag', function() return getProperty('camGame.alpha') end, function(v) setProperty('camGame.alpha', v) end, g, dur, ease)
	addTween('ah', function() return getProperty('camHUD.alpha') end, function(v) setProperty('camHUD.alpha', v) end, h, dur, ease)
end

-- ---------------------------------------------------------------- extra library events (FlashWhite, Drunk)
E.VS_FlashWhite = function(p)
	local dur, a = steps(num(p.v1, 4)), clamp01(num(p.v2, 1))
	if not luaSpriteExists('vsFlashW') then
		makeLuaSprite('vsFlashW', nil, 0, 0); makeGraphic('vsFlashW', screenWidth, screenHeight, 'FFFFFF')
		setObjectCamera('vsFlashW', 'camOther'); setScrollFactor('vsFlashW', 0, 0); addLuaSprite('vsFlashW', true)
	end
	setProperty('vsFlashW.alpha', a); doTweenAlpha('vsFlashWT', 'vsFlashW', 0, dur, 'linear')
end

local DRUNK = {on = false, x = 50, y = 30, a = 2, speed = 0.5, t = 0}
DRUNK_TICK = function(elapsed)
	if not DRUNK.on then return end
	DRUNK.t = DRUNK.t + elapsed * DRUNK.speed * 3
	setProperty('camGame.angle', DRUNK.a * math.sin(DRUNK.t))
	setProperty('camGame.x', DRUNK.x * 0.1 * math.sin(DRUNK.t * 0.7))
	setProperty('camGame.y', DRUNK.y * 0.1 * math.cos(DRUNK.t * 0.9))
end
E.VS_Drunk = function(p)
	DRUNK.on = truthy(p.v1) or p.v1 == nil
	DRUNK.x, DRUNK.y, DRUNK.a, DRUNK.speed = num(p.v2, 50), num(p.v3, 30), num(p.v4, 2), num(p.v5, 0.5)
	if not DRUNK.on then setProperty('camGame.angle', 0); setProperty('camGame.x', 0); setProperty('camGame.y', 0) end
end

function onEvent(name, v1, v2)
	local f = E[name]
	if f == nil then return end
	local ok, err = pcall(f, P(v1))
	if not ok then debugPrint('PortYou V-Slice event ' .. tostring(name) .. ': ' .. tostring(err)) end
end

function onCreatePost()
	setProperty('camGame.alpha', 1); setProperty('camHUD.alpha', 1)
	for slot, s in pairs(SLOT) do
		if s.dance ~= nil and s.dance ~= 2 and slot ~= 'gf' then
			setProperty(slot .. '.danceEveryNumBeats', s.dance)
		end
	end
end
