package com.portyou.studio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool

class Sound(private val ctx: Context, private val prefs: Prefs) {
    private var bgm: MediaPlayer? = null
    private val pool = SoundPool.Builder().setMaxStreams(4)
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build()).build()
    private val ids = HashMap<String, Int>()

    init {
        for (n in listOf("sfx_click", "sfx_success", "sfx_fail"))
            ctx.assets.openFd("ui/$n.ogg").use { ids[n] = pool.load(it, 1) }
    }

    fun startMusic() {
        if (prefs.musicMuted) return
        if (bgm == null) {
            bgm = MediaPlayer().apply {
                ctx.assets.openFd("ui/bgm.ogg").use { setDataSource(it.fileDescriptor, it.startOffset, it.length) }
                isLooping = true; prepare()
            }
        }
        bgm?.start()
    }
    fun pauseMusic() { bgm?.takeIf { it.isPlaying }?.pause() }
    fun applyMusicSetting() { if (prefs.musicMuted) pauseMusic() else startMusic() }
    fun play(name: String) {
        if (prefs.sfxMuted) return
        ids[name]?.let { pool.play(it, 1f, 1f, 1, 0, 1f) }
    }
    fun release() { bgm?.release(); bgm = null; pool.release() }
}
