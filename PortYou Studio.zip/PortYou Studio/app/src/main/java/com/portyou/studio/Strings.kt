package com.portyou.studio

/** Language order matches the flags image: 0 Algeria, 1 Brazil, 2 Saudi, 3 Iraq, 4 USA, 5 Japan. */
object Strings {
    const val DZ = 0; const val PT = 1; const val SA = 2; const val IQ = 3; const val EN = 4; const val JA = 5
    fun isArabic(l: Int) = l == DZ || l == SA || l == IQ
    /** Description art per language (Arabic dialects share desc_ar). */
    fun descImage(l: Int) = when (l) { PT -> "desc_pt"; EN -> "desc_en"; JA -> "desc_ja"; else -> "desc_ar" }

    // 24 sayings of Akram (the LAST one is the "tea" saying: the fail icon is drawn over the bubble) (speech bubble), 3 for Instagram taps, 4 for YouTube taps
    val akram: Array<Array<String>> = arrayOf(
        arrayOf( // DZ
            "أنا أسطورة يا خو", "عندي وحدة تحبني وانت لا هههههه", "والله سوّيني ستوري", "شحّات باقة الإنترنت", "نحب دراهمك",
            "اشترك وراني نعطيك هدية إذا ما نسيت", "مرة كان واحد شعره أزرق", "ديما يا خو", "منين تعرفني أنت", "واحد زائد واحد كم؟",
            "اشترك فيه المسكين راه يشحت", "واش رايك في سكني", "صاحب العيون السوداء علاش جابني هنا",
            "تزوجني نرجوك", "أنا حامل", "نمزح والله", "مستر بيست أعطيني توقيعك !!", "شوف قناتي بالله عليك ما تاخذ منك ربع ساعة", "جربت نطيّب وياليتني ما دخلت للمطبخ", ":3", "🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣", "أنا مريض نفسي ما تهتمش للأمر", "قاعد نهبّل والله", "نصبّلك أتاي ؟"),
        arrayOf( // PT
            "Eu sou uma lenda, mano", "Eu tenho namorada e você não, hahaha", "Por favor, me faz um story", "Mendigando pacote de internet",
            "Eu amo o seu dinheiro", "Se inscreve que eu te dou um presente, se eu não esquecer", "Uma vez tinha um cara de cabelo azul",
            "Sempre, mano", "De onde você me conhece?", "1+1 quanto dá?", "Se inscreve nele, coitado, tá pedindo esmola",
            "O que você acha do meu estilo?", "Dono dos olhos pretos, por que me trouxe aqui?",
            "Casa comigo, por favor", "Eu estou grávida", "Brincadeira, juro", "Mr Beast, dá o seu autógrafo!!", "Vê o meu canal, por favor, não vai levar nem 15 minutos", "Tentei cozinhar e queria nunca ter entrado na cozinha", ":3", "🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣", "Eu sou doente da cabeça, não liga pra isso", "Tô aqui só zoando, juro", "Faço um chá pra você?"),
        arrayOf( // SA
            "أنا أسطورة يا زم", "عندي حبيبة وأنت لا هههههه", "بالله سوّيني ستوري", "شحّات باقة النت", "أحب فلوسك",
            "اشترك وأعطيك هدية لو ما نسيت", "مرة كان في واحد شعره أزرق", "ديم يا زم", "من وين تعرفني أنت", "1+1 كم؟",
            "اشترك له المسكين ذا شحّات", "رأيك بسكني؟", "صاحب العيون السوداء ليش جابني هنا",
            "تزوجني أرجوك", "أنا حامل", "أمزح والله", "مستر بيست بده توقيعي !!", "شوف قناتي بالله عليك ما تاخذ منك ربع ساعة", "جربت أطبخ وياليتني ما دخلت المطبخ", ":3", "🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣", "أنا مريض نفسي ما تكترث للأمر", "جالس أهبد والله", "أعملك شاي ؟"),
        arrayOf( // IQ
            "آني أسطورة خوش", "عندي حبيبة وإنت لا هههههه", "عاشت إيدك سوّيلي ستوري", "شحّاذ باقة نت", "أحب فلوسك",
            "اشترك وأعطيك هدية إذا ما نسيت", "مرة كان اكو واحد شعره أزرق", "دايماً خوش", "منين تعرفني إنت", "واحد زائد واحد شكد؟",
            "اشترك بيه المسكين يشحذ", "شرأيك بسكني؟", "صاحب العيون السود ليش جابني لهنا",
            "تزوجني رجاءً", "آني حامل", "أمزح والله", "مستر بيست اعطيني توقيعك !!", "شوف قناتي والله ما تاخذ منك ربع ساعة", "جربت أطبخ وياريتني ما دخلت المطبخ", ":3", "🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣", "آني مريض نفسي لا تهتم للأمر", "قاعد أخربط والله", "أسوّيلك چاي ؟"),
        arrayOf( // EN
            "I'm a legend, bro", "I have a girlfriend and you don't, hahaha", "Please make me a story", "Begging for an internet plan",
            "I love your money", "Subscribe and I'll give you a gift, if I don't forget", "Once there was a guy with blue hair",
            "Always, bro", "Where do you know me from?", "1+1 equals what?", "Subscribe to him, poor guy is still begging",
            "What do you think of my skin?", "Black-eyed guy, why did you bring me here?",
            "Marry me, please", "I am pregnant", "Just kidding, I swear", "MrBeast, give me your autograph!!", "Check out my channel, please, it will not even take fifteen minutes", "I tried cooking and I wish I never walked into the kitchen", ":3", "🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣", "I am mentally ill, do not mind it", "Just messing around, I swear", "Should I make you some tea?"),
        arrayOf( // JA
            "俺は伝説だぜ", "俺には彼女がいるけど、君にはいないｗ", "お願い、ストーリーに載せて", "ネットの通信量をねだってる", "君のお金、大好き",
            "登録してくれたら、忘れなければプレゼントあげるよ", "昔、青い髪のやつがいてさ", "いつもだぜ", "どこで俺のこと知ったの？", "1+1はいくつ？",
            "あいつを登録してあげて、まだ物乞いしてるから", "俺のスキン、どう思う？", "黒い瞳のやつ、なんで俺をここに連れてきたの？",
            "結婚してください", "妊娠したんだ", "冗談だよ、マジで", "ミスタービースト、サインちょうだい！！", "俺のチャンネル見てよ、15分もかからないから", "料理してみたけど、台所に入らなきゃよかった", ":3", "🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣", "俺は心の病気だから、気にしないで", "ただふざけてるだけだよ、ほんと", "お茶いれようか？"))

    val instaSay: Array<Array<String>> = arrayOf(
        arrayOf("راح يسحب عليك", "تابعه وما تنساني معاه", "على أساس راح يرد عليك"),
        arrayOf("Ele vai te ignorar", "Segue ele e não me esquece", "Como se ele fosse responder"),
        arrayOf("رح يسحب عليك", "تابعه وما تنساني معاه", "على أساس رح يرد عليك"),
        arrayOf("راح يطنشك", "تابعه وما تنساني وياه", "على أساس راح يرد عليك"),
        arrayOf("He's going to ghost you", "Follow him and don't forget me", "As if he'll reply"),
        arrayOf("無視されるよ", "フォローして、俺のことも忘れないで", "返事が来るとでも？"))

    val ytSay: Array<Array<String>> = arrayOf(
        arrayOf("شوف شوف المحتوى تاعي أحسن", "اشترك فيه المسكين مازال يشحّت", "العفوية إذن", "واش قصّرت معاك؟"),
        arrayOf("Olha só, meu conteúdo é melhor", "Se inscreve nele, coitado, ainda tá pedindo", "Naturalidade, então", "Em que eu falhei com você?"),
        arrayOf("شوف شوف محتواي أحسن", "اشترك له المسكين لسّاته يشحّت", "العفوية أجل", "أنا في إيش قصّرت معك؟"),
        arrayOf("شوف شوف محتواي أحسن", "اشترك بيه المسكين بعده يشحذ", "العفوية إذن", "آني شنو قصّرت وياك؟"),
        arrayOf("Look, look, my content is better", "Subscribe to him, poor guy is still begging", "Spontaneity, then", "How did I fall short with you?"),
        arrayOf("見て見て、俺のコンテンツのほうが上だぜ", "あいつを登録してあげて、まだ物乞い中だから", "自然体ってことさ", "俺、何か足りなかった？"))

    val unsupported = arrayOf("المود غير مدعوم", "Mod não suportado", "المود غير مدعوم", "المود غير مدعوم", "Mod not supported", "このMODは非対応です")
    val savedIn = arrayOf("تم الحفظ في المجلد: ", "Salvo na pasta: ", "تم الحفظ في المجلد: ", "تم الحفظ في المجلد: ", "Saved in folder: ", "保存先フォルダ: ")
    val pickTitle = arrayOf("اختر ملف المود", "Escolha o arquivo do mod", "اختر ملف المود", "اختر ملف المود", "Choose the mod file", "MODファイルを選択")

    val description = arrayOf(
        "PortYou Studio يحوّل مودات V-Slice وFunky Maker إلى Psych Engine بضغطة زر، بدون إنترنت.",
        "O PortYou Studio converte mods V-Slice e Funky Maker para o Psych Engine com um toque, offline.",
        "PortYou Studio يحوّل مودات V-Slice وFunky Maker إلى Psych Engine بضغطة زر، بدون إنترنت.",
        "PortYou Studio يحوّل مودات V-Slice وFunky Maker إلى Psych Engine بكبسة زر، بدون إنترنت.",
        "PortYou Studio converts V-Slice and Funky Maker mods to Psych Engine with one tap, fully offline.",
        "PortYou Studio は V-Slice と Funky Maker のMODをワンタップで Psych Engine に変換します（オフライン対応）。")
}
