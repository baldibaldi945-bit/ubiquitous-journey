"""Credits that EVERY converted mod gets (V-Slice and Funky Maker): pack.json, pack.png and the on-screen watermark script."""
import json, os, shutil

CREDIT_EN = 'This mod was ported by the AxelzeroX23 app (PortYou Studio)'
CREDIT_PT = 'Este mod foi portado pelo app do AxelzeroX23 (PortYou Studio)'

# same script as the supplied text.lua, with the name replaced by "Port You Studio"
CREDIT_LUA = '''function onCreate()
makeLuaText('watermark', "Port You Studio", 0, 10, 550);
    setTextSize('watermark', 20);
    addLuaText('watermark');
end
'''


def write(out, title, pack_png=None, color=(170, 0, 255)):
    os.makedirs(os.path.join(out, 'scripts'), exist_ok=True)
    with open(os.path.join(out, 'scripts', 'portyou_credit.lua'), 'w', encoding='utf-8', newline='\n') as f:
        f.write(CREDIT_LUA)
    with open(os.path.join(out, 'pack.json'), 'w', encoding='utf-8') as f:
        json.dump(dict(name='%s | %s | %s' % (title, CREDIT_EN, CREDIT_PT),
                       description='%s. / %s. YouTube: axelzerox023 | Instagram: axelzerox023' % (CREDIT_EN, CREDIT_PT),
                       restart=False, runsGlobally=False, color=list(color), discordRPC=':)', iconFramerate=10), f, indent=1, ensure_ascii=False)
    if pack_png and os.path.isfile(pack_png):
        shutil.copy(pack_png, os.path.join(out, 'pack.png'))
